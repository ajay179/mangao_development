@include('login-auth-file.header')

@yield('content')

@include('login-auth-file.js')
