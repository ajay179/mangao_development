<?php

namespace App\Http\Controllers\admin;

use App\models\MangaoStaticUseradmin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Auth;

class Cn_dashboard extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // echo $password = Hash::make('123456');
        
        if (Gate::allows('isSuperAdmin')) {

           echo "you are admin";

        } else {

            echo "you are not admin";

        }

        // die();
        // return view('admin.dashbord.dashbord');
    }
}
