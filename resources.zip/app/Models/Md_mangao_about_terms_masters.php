<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Md_mangao_about_terms_masters extends Model
{
    use HasFactory;
    protected $table ='mangao_about_terms_masters'; 
    public $timestamps = false;
}
