<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Md_mangao_categories extends Model
{
    use HasFactory;
    protected $table ='mangao_categories';	
    public $timestamps = false;
}
