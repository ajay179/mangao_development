<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Md_mangao_redeem_point extends Model
{
    use HasFactory;
    protected $table ='mangao_redeem_point'; 
    public $timestamps = false;
}
