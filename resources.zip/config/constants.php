<?php 

return [

	// define  constant using array

    // 'options' => [
    //     'option_attachment' => '13',
    //     'option_email' => '14',
    //     'option_monetery' => '15',
    //     'option_ratings' => '16',
    //     'option_textarea' => '17',
    // ]


    //define direct constant

    'MANGAO_CITY_MASTER'=>'mangao_city_masters',
    'MANGAO_CITY_ADMIN'=>'mangao_city_admins',
    'MANGAO_CATEGORY_MASTER'=>'mangao_categories',
    'MANGAO_WALLET_NORMAL_PLAN'=>'mangao_wallet_noraml_plan',
    'MANGAO_BANNER_MASTER'=>'mangao_banner_masters',
    'MANGAO_ABOUT_TERMS_MASTERS'=>'mangao_about_terms_masters',
    'MANGAO_REDEEM_POINTS'=>'mangao_redeem_point',
    'MANGAO_VENDORS'=>'mangao_vendors',
    'MANGAO_DELIVERY_BOY'=>'mangao_delivery_boy',


    
];

?>