
<?php if (isset($component)) { $__componentOriginalb8ec812318d04beab29d6c1eb73bee9e0f6c9981 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Head::class, []); ?>
<?php $component->withName('admin.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8ec812318d04beab29d6c1eb73bee9e0f6c9981)): ?>
<?php $component = $__componentOriginalb8ec812318d04beab29d6c1eb73bee9e0f6c9981; ?>
<?php unset($__componentOriginalb8ec812318d04beab29d6c1eb73bee9e0f6c9981); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Header::class, []); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757)): ?>
<?php $component = $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757; ?>
<?php unset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal16922a32012e445d83def1b667bd8c380818a472 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Navbar::class, []); ?>
<?php $component->withName('admin.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16922a32012e445d83def1b667bd8c380818a472)): ?>
<?php $component = $__componentOriginal16922a32012e445d83def1b667bd8c380818a472; ?>
<?php unset($__componentOriginal16922a32012e445d83def1b667bd8c380818a472); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.vendor.vendor_sidebar','data' => []]); ?>
<?php $component->withName('vendor.vendor_sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>

<?php if (isset($component)) { $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Footer::class, []); ?>
<?php $component->withName('admin.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4)): ?>
<?php $component = $__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4; ?>
<?php unset($__componentOriginal273b99c895545dc613f61f0747b5dd769beb60e4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal1c131de84c347d1f065a1414b9583b6bbf8d77fe = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Jsfiles::class, ['classname' => ''.e(!empty($class_name) ? $class_name: '').'']); ?>
<?php $component->withName('admin.jsfiles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c131de84c347d1f065a1414b9583b6bbf8d77fe)): ?>
<?php $component = $__componentOriginal1c131de84c347d1f065a1414b9583b6bbf8d77fe; ?>
<?php unset($__componentOriginal1c131de84c347d1f065a1414b9583b6bbf8d77fe); ?>
<?php endif; ?>

<!-- for datatables purpose  -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
   	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

   	<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

<?php echo $__env->yieldContent('js_section'); ?>


<?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/vendor/layout/layout.blade.php ENDPATH**/ ?>