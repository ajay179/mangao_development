
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Mangao Mart</title>
  <!-- Tell the browser to be responsive to screen width -->
 
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

</head>

<body class="">
  <div class="container" id="container">
    <div class="form-container sign-in-container">
      <form method="POST" id="laravelVendorLoginForm" action="<?php echo e(url('check-login-for-vendor')); ?>">
        <?php echo csrf_field(); ?>
        <h1> <img src="<?php echo e(asset('commonarea/dist/img/logo.png')); ?>" style="height: 170px;" alt="logo"></h1>
      
        <div class="col-md-12">
          <input type="email" placeholder="Email" name="email"/>
        </div>
        <div class="col-md-12">
          <input type="password" placeholder="Password" id="password" name="password" />
          <span class="pass-show"><i class="fa fa-eye-slash"></i></span>
        </div>
        <div class="col-md-12">
          <div class="pad-10px mb-10px">
            <a href="<?php echo e(url('/')); ?>">Forgot your password?</a>
          </div>
        </div>
        <div class="col-md-12">
        <input type="submit" value="submit" class="btn btn-primary">
        </div>
      </form>
    </div>
    
  </div>



</body>

</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('login-auth-file.loginauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/vendor/login/login.blade.php ENDPATH**/ ?>