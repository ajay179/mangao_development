<?php echo $__env->make('login-auth-file.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('login-auth-file.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/login-auth-file/loginauth.blade.php ENDPATH**/ ?>