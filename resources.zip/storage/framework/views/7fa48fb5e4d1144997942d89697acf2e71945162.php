
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
        <div class="row no-margin">
            <div class="col-md-12  no-pad">
                <section class="content-header">
                    <h1>Completed Orders </h1>
                </section>
                <section class="content" style="padding:5px 0px;">
                    <div class="box box-primary">
                        <div class="box-body light-green-body">
                            <table id="example" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th width="7%">Sr No.</th>
                                        <!-- <th width="15%">City</th> -->
                                        <th width="15%">Name</th>
                                        <th width="15%">Mobile No.</th>
                                        <th width="15%">Email</th>
                                        <th width="20%">Image </th>
                                        <th width="20%">Date </th>
                                        <th width="10%" style="min-width: 80px;" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>

                        </div> <!-- End box-body -->
                    </div> <!-- End box -->
                </section>
            </div>


        </div>
        <!-- /.row -->
    </section>
</div>


<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js_section'); ?>
<script type="text/javascript">
    $(".s_meun").removeClass("active");
    $(".orders_management_active").addClass("active");
    $(".completed_order_menu").addClass("active");
</script>
<script type="text/javascript">
  $("#example").dataTable();
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/admin/orders/completed_orders.blade.php ENDPATH**/ ?>