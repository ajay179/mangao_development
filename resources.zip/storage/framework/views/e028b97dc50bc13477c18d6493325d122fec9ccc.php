<div>
    <!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div><?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/components/admin/header.blade.php ENDPATH**/ ?>