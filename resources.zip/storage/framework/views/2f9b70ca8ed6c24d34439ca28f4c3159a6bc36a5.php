

<?php $__env->startSection('content'); ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>Dashboard</h1>
            </section>
            <!-- Info boxes -->
            <div class="box box-primary">
                <div class="box-body">
                    <section class="statis mt-4 text-center">
                        <div class="row">
                            <div class="col-xs-12 col-md-4 col-lg-4 mb-4 mb-lg-0 ">
                                <a href="#">
                                    <div class="box bg-1 bg-primary p-3">
                                        <i class="fa fa-user"></i>
                                        <h3>23</h3>
                                        <p class="lead">Total Students</p>
                                    </div>
                                </a>
                            </div>
                            <!-- <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">
                      <div class="box bg-2 bg-primary p-3">
                         <i class="fa fa-male"></i>
                         <h3>500</h3>
                         <p class="lead">Total Teachers</p>
                      </div>
                   </div> -->
                   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view')): ?>
                            <div class="col-xs-12 col-md-4 col-lg-4 mb-4 mb-lg-0">
                                <a href="#">
                                    <div class="box bg-3 bg-primary p-3">
                                        <i class="fa fa-male"></i>
                                        <h3>2</h3>
                                        <p class="lead">Total Teachers</p>
                                    </div>
                                </a>
                            </div>
                            
                            <div class="col-xs-12 col-md-4 col-lg-4 mb-4 mb-lg-0">
                                <a href="#">
                                    <div class="box bg-5 bg-primary p-3">
                                        <i class="fa fa-bullhorn"></i>
                                        <h3>34</h3>
                                        <p class="lead">Total Announcements</p>
                                    </div>
                                </a>
                            </div>

                            <?php endif; ?>
                        </div>
                        <!-- /.row -->
                        <div class="row">
                            <div class="col-md-4 col-lg-4 mb-4 mb-lg-0">
                                <a href="#">
                                    <div class="box bg-6 bg-primary p-3">
                                        <i class="fa fa-bullseye"></i>
                                        <h3 class="no-border mb-20">Support Tickets </h3>
                                        <div class="col-xs-4 col-md-4 col-lg-4 mb-4 mb-lg-0">
                                            <h3 class="mt-10">45
                                                </h3>
                                            <p class="lead">Pending</p>
                                        </div>
                                        <div class="col-xs-4 col-md-4 col-lg-4 mb-4 mb-lg-0 border-l-r ">
                                            <h3 class="mt-10">76
                                                 </h3>
                                            <p class="lead">Inprocess</p>
                                        </div>
                                        <div class="col-xs-4 col-md-4 col-lg-4 mb-4 mb-lg-0">
                                            <h3 class="mt-10">73
                                                 </h3>
                                            <p class="lead">Completed</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-md-4 col-lg-4 mb-4 mb-lg-0">
                                <a href="#">
                                    <div class="box bg-4 bg-primary p-3">
                                        <i class="fa fa-book"></i>

                                        <h3 class="no-border mb-20">Homework </h3>
                                        <div class="col-xs-6 col-md-6 col-lg-6 mb-4 mb-lg-0 border-r">
                                            <h3 class="mt-10">987
                                                </h3>
                                            <p class="lead">Pending</p>
                                        </div>
                                        <div class="col-xs-6 col-md-6 col-lg-6 mb-4 mb-lg-0">
                                            <h3 class="mt-10">34
                                                </h3>
                                            <p class="lead">Completed</p>
                                        </div>

                                    </div>
                                </a>
                            </div>
                            <!-- <div class="col-md-6 col-lg-6 mb-4 mb-lg-0">
                      <div class="box bg-2 bg-primary p-3">
                         <i class="fa fa-male"></i>
                         <h3>500</h3>
                         <p class="lead">Total Teachers</p>
                      </div>
                   </div> -->
                            <div class="col-md-4 col-lg-4 mb-4 mb-lg-0">

                                <a href="#">
                                    <div class="box bg-7 bg-primary p-3">
                                        <i class="fa fa-money"></i>
                                        <h3 class="no-border mb-20">Accounts</h3>
                                        <div class="col-xs-6 col-md-6 col-lg-6 mb-4 mb-lg-0 border-r">
                                            <h3 class="mt-10">
                                                2
                                            </h3>
                                            <p class="lead">Outstanding</p>
                                        </div>
                                        <div class="col-xs-6 col-md-6 col-lg-6 mb-4 mb-lg-0">
                                            <h3 class="mt-10">56
                                            </h3>
                                            <p class="lead">Paid</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                        </div>
                    </section>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_section'); ?>
    <script type="text/javascript">
    $(".s_menu").removeClass("active");
    $(".dashboard_active").addClass("active");
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminarea.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/admin/dashboard/dashbord.blade.php ENDPATH**/ ?>