    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar scrollbar" id="style-7">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu" data-widget="tree">
                <!-- Dashboard start-->
                <li class="s_meun dashboard_active active">
                    <a href="<?php echo e(url('vendor-dashbord')); ?>">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>
                <!-- Dashboard end-->

                


                
            


                <!--Settings end-->
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside><?php /**PATH C:\xampp\htdocs\mangao_development\resources\views/components/vendor/vendor_sidebar.blade.php ENDPATH**/ ?>